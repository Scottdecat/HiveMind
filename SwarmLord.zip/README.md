This bot is the HiveMind
Author: Scott Desai





Takers inspiration from 
# SLUDGEMENT 2

## Authors
Blodir (Pyry Mäkinen)
Antis (Nikola Pratte)

This bot was written for the Reaktor Artificial Overmind Challenge. It played Starcraft II at an estimated high diamond/low masters level (top 4%) in 2019.
The bot was at the top of the Reaktor competition ladder for more than a month, eventually being featured in a showmatch against Serral, who is one of the best players in the world currently. A video of this can be found here: https://www.youtube.com/watch?v=7HWfMJ_8f0A. Match against Serral starts around 8:05. Second match starts around 33:35.