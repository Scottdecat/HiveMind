# re-export
from .main import MyBot
