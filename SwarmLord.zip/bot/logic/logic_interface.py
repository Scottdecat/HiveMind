class LogicInterface():
    async def on_step(self, iteration):
        raise NotImplementedError("Not implemented")