from bot.services.unit_group_service import UnitGroup

class AssignedGroup:
    group: UnitGroup
    retreaters: UnitGroup
    enemies: UnitGroup