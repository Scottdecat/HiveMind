from enum import Enum

class UnitTypeAbstraction(Enum):
    # TODO: refactor ECONOMY --> WORKER
    ECONOMY = 10000
    ARMY = 10001